# Install
Follow The Steps Below!

```python2
> apt install python2 -y
> apt install git -y
> git clone https://github.com/4NK3R-PRODUCT1ON/T4MPILAN-V5
> cd T4MPILAN-V5
> python2 style5.py
